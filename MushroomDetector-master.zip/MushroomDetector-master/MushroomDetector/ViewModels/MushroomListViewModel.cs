﻿using System;
using TinyMvvm;

namespace MushroomDetector.ViewModels
{
    public class MushroomListViewModel : ViewModelBase
    {
        public MushroomListViewModel()
        {
        }
    }
}
