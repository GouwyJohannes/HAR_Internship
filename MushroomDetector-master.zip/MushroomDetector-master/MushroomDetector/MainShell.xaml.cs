﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace MushroomDetector
{
    public partial class MainShell
    {
        public MainShell()
        {
            InitializeComponent();
        }
    }
}
