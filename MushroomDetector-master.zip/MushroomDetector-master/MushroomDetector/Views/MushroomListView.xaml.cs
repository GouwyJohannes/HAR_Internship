﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace MushroomDetector.Views
{
    public partial class MushroomListView
    {
        public MushroomListView()
        {
            InitializeComponent();
        }
    }
}
