﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace MushroomDetector.Views
{
    public partial class ResultView
    {
        public ResultView()
        {
            InitializeComponent();
        }
    }
}
