﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace MushroomDetector.Views
{
    public partial class MainView
    {
        public MainView()
        {
            InitializeComponent();
        }
    }
}
