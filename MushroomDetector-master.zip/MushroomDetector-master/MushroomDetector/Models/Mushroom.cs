﻿using System;
namespace MushroomDetector.Models
{
    public class Mushroom
    {
        public string Name { get; set; }
        public string LatinName { get; set; }
        public string WikipediaUrl { get; set; }
        public string PhotoUrl { get; set; }
    }
}
